# PerpustakaanApp
Ini adalah aplikasi perpustakaan app menggunakan database sqlite

<img width="960" alt="ppsapp" src="https://user-images.githubusercontent.com/45890656/103523604-af76b300-4eae-11eb-8f74-465b050c31fe.PNG">



## fitur
1. Create data Buku
2. Hapus data buku
3. Sorting buku (dipinjam , dikembalikan)

## Source
Abror Rahmad

DeX PY
